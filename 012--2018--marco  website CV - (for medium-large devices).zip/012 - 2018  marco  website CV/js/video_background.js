// The video background Cup of Coffe is too fast I slowed it down to half of its original speed
let videoSpeed = document.getElementById('myCupOfCoffeVideo')
videoSpeed.playbackRate = 0.5
